<?php $__env->startSection('page-title', 'Products'); ?>

<?php $__env->startSection('main-content'); ?>
    <section class="content">
        <div class="body_scroll">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="card">
                            <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <div class="header">
                                <h2 class="float-left"><strong>All</strong> Products</h2>
                                <div class="header-right float-right">
                                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary">Add New</a>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover c_table">
                                    <thead>
                                    <tr>
                                        <th style="width:60px;">Sl.</th>
                                        <th>Name</th>
                                        <th>New Price</th>
                                        <th>Old Price</th>
                                        <th>Quantity</th>
                                        <th>Category</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e(str_limit($product->name, 15, '...')); ?></td>
                                            <td>$ <?php echo e($product->sale_price); ?></td>
                                            <td>$ <?php echo e($product->unit_price); ?></td>
                                            <td><?php echo e($product->quantity); ?></td>
                                            <td><?php echo e($product->category->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info btn-sm waves-effect"><i class="zmdi zmdi-eye"></i></a>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-success waves-effect waves-float btn-sm waves-light"><i class="zmdi zmdi-edit"></i></a>
                                                <a href="<?php echo e(route('products.destroy', $product->id)); ?>" class="btn btn-danger waves-effect waves-float btn-sm waves-light data-delete"><i class="zmdi zmdi-delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <form id="delete-form"  method="post" style="display:none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startPush('page-scripts'); ?>
    <script>
            var products = document.querySelectorAll('.data-delete');
            var deleteForm = document.getElementById('delete-form');
            for(var product of Array.from(products)) {
                product.addEventListener('click', function(event) {
                    event.preventDefault();
                    var action = this.href;
                    deleteForm.action = action;
                    deleteForm.submit();
                });

            }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
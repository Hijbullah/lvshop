<!doctype html>
<html class="no-js " lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">

    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo $__env->yieldContent('page-title'); ?></title>

    <link rel="icon" href="<?php echo e(asset('backend/favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/bootstrap/css/bootstrap.min.css')); ?>"> 
    <?php echo $__env->yieldPushContent('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/style.min.css')); ?> ">
</head>

<body class="theme-blush">
    <div id="app">
        

        <!-- Overlay For Sidebars -->
        <div class="overlay"></div>
        <?php echo $__env->make('backend._includes.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('backend._includes.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('backend._includes.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Main Content -->
        <section class="content">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-7 col-md-6 col-sm-12">
                        <h2>eCommerce Dashboard</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="zmdi zmdi-home"></i> Aero</a></li>
                            <li class="breadcrumb-item">eCommerce</li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ul>
                        <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                    </div>
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                    </div>
                </div>
            </div>
        </section>

        <?php echo $__env->yieldContent('main-content'); ?>
    </div>

    <!-- Jquery Core Js -->
    
    <script src="<?php echo e(asset('backend/bundles/libscripts.bundle.js')); ?> "></script>
    <!-- Lib Scripts Plugin Js -->
    <script src="<?php echo e(asset('backend/bundles/vendorscripts.bundle.js')); ?> "></script>
    <!-- Lib Scripts Plugin Js -->
    <?php echo $__env->yieldPushContent('page-scripts'); ?>
    <script src="<?php echo e(asset('backend/bundles/mainscripts.bundle.js')); ?> "></script>

</body>

</html>
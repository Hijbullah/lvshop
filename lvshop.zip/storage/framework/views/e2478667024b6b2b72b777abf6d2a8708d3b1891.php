<ul class="">
    <li>
        <div class="radio">
            <input type="radio" id="<?php echo e($category->id); ?>"  name="category_id" value="<?php echo e($category->id); ?>">
            <label for="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </label>
            
        </div>
        <?php if(count($category->children) > 0): ?>
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('backend.pages.products.category-child', $category, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </li>
    
</ul>
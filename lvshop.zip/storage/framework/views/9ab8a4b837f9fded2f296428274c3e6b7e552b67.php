
<!-- Left Sidebar -->
<aside id="leftsidebar" class="sidebar">
    <div class="navbar-brand">
        <button class="btn-menu ls-toggle-btn" type="button"><i class="zmdi zmdi-menu"></i></button>
        <a href="#"><img src="<?php echo e(asset('backend/images/logo.svg')); ?>" width="25" alt="Aero"><span class="m-l-10">Aero</span></a>
    </div>
    <div class="menu">
        <ul class="list">
            <li>
                <div class="user-info">
                    <a class="image" href="#"><img src="<?php echo e(asset('backend/images/profile_av.jpg')); ?>" alt="User"></a>
                    <div class="detail">
                        <h4><?php echo e(auth()->guard('admin')->user()->name); ?></h4>
                        <small>Super Admin</small>
                    </div>
                </div>
            </li>
            <li class="<?php echo e(request()->is('admin') ? 'active' : ''); ?>"><a href=" <?php echo e(route('admin.dashboard')); ?> "><i class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
            <li class="<?php echo e(request()->is('admin/categories*') ? 'active' : ''); ?>"><a href=" <?php echo e(route('categories.index')); ?> "><i class="zmdi zmdi-apps"></i><span>Categories</span></a></li>
            <li class="<?php echo e(request()->is('admin/products*') ? 'active' : ''); ?>""><a href=" <?php echo e(route('products.index')); ?> "><i class="zmdi zmdi-shopping-cart"></i><span>Products</span></a></li>
            
            <li class="open_top"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-lock"></i><span>Administrator</span></a>
                <ul class="ml-menu">
                    <li><a href="#">Admins Section</a></li>
                    <li><a href="#">Roles Section</a></li>
                    <li><a href="#">Permissions section</a></li>
                </ul>
            </li> 
        </ul>
    </div>
</aside>

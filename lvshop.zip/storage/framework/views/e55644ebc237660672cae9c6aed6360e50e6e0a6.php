<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img class="zmdi-hc-spin" src="<?php echo e(asset('backend/images/loader.svg')); ?>" width="48" height="48" alt="Aero"></div>
        <p>Please wait...</p>
    </div>
</div>

<ul class="">
    <li>
        <div class="radio cat-radio-item">
            <input type="radio" id="<?php echo e($category->id); ?>" name="parent_id" value="<?php echo e($category->id); ?>">
            <label for="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </label>
            <a href="<?php echo e(route('categories.destroy', $category->id)); ?>" class="btn btn-round btn-danger waves-effect waves-float btn-sm waves-light cat-data-delete"><i class="zmdi zmdi-delete"></i></a>

            
        </div>
        <?php if(count($category->children) > 0): ?>
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('backend.pages.categories.child', $category, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </li>
    
</ul>
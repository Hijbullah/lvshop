<?php include('header.php');?>
<!-- page-content -->
<div class="page-header">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-md-12">
				<div class="page-area">
					<img src="img/page-banner/cat-banner.jpg" alt="">
					<div class="page-link">
						<ul class="page-menu">
							<li><a href="">Home</a></li>
							<li><a href="">Category</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="category-page-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="all-caterory">
					<div class="row">

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/1.jpg" alt="">
								<h3>Custom Wheels</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/2.jpg" alt="">
								<h3>Headlights</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/3.jpg" alt="">
								<h3>Tires</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/4.jpg" alt="">
								<h3>Exhaust Systems</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/5.jpg" alt="">
								<h3>Custom Wheels</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/6.jpg" alt="">
								<h3>Headlights</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/7.jpg" alt="">
								<h3>Tires</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/8.jpg" alt="">
								<h3>Exhaust Systems</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/9.jpg" alt="">
								<h3>Custom Wheels</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/10.jpg" alt="">
								<h3>Headlights</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/11.jpg" alt="">
								<h3>Tires</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

						<div class="col-md-3">
							<div class="single-caterory">
								<img src="img/category/12.jpg" alt="">
								<h3>Exhaust Systems</h3>
								<p class="price"><span>$300</span>$100</p>
								<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
								<button class="card-button btn btn-gray btn-sm "> View Details </button>
								<button class="card-button btn btn-dark btn-sm "> Add To Card </button>
							</div>
						</div>

					</div>
					<nav aria-label="...">
					  <ul class="pagination justify-content-end">
					    <li class="page-item disabled">
					      <a class="page-link" href="#" tabindex="-1">Previous</a>
					    </li>
					    <li class="page-item"><a class="page-link" href="#">1</a></li>
					    <li class="page-item active">
					      <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
					    </li>
					    <li class="page-item"><a class="page-link" href="#">3</a></li>
					    <li class="page-item">
					      <a class="page-link" href="#">Next</a>
					    </li>
					  </ul>
					</nav>

				</div>
				
			</div>
		</div>
	</div>
</div>

<!-- page-content -->

<?php include('footer.php');?>
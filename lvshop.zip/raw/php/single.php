<?php include('header.php');?>
<!-- page-content -->
<div class="page-header">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-md-12">
				<div class="page-area">
					<img src="img/page-banner/cat-banner.jpg" alt="">
					<div class="page-link">
						<ul class="page-menu">
							<li><a href="">Home</a></li>
							<li><a href="">Product</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="category-page-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="single-page">
					<div class="row">

					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- page-content -->

<?php include('footer.php');?>
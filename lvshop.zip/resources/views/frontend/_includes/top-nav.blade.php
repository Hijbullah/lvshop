<!-- search box toggle show -->
<div class="search-box-toggle-show" id="closesearch">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-12">
                <form action="">
                    <input type="text" name="" id="search" placeholder="Search">

                    <button type="button" onclick="closesearch()"><i class="far fa-window-close"></i></button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- search box togeel show end-->

<!-- top-narbar-start-->
<div class="top-bar-area">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-12">
                <div class="top-bar">
                    <div class="row">
                        <div class="col-md-1">
                            <div class="help-desk">
                                <a href="#">Help Desk</a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="company-id">
                                <a href="#">1-888-DIESEL-4</a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="no-extra-charge">
                                <p>No Handling Fees • Free Shipping on orders over $50.00*</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="search-box">
                                <form action="">
                                    <input type="text" name="" id="search" placeholder="Search">

                                    <button type="button"><i class="fab fa-searchengin"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- top-narbar end-->